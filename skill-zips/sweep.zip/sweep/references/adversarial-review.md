# Writing a review that pitboss reads

You were started to review one pull request, independently of its author.
Your review is a comment on the PR, in the form the project's configuration
sets for that repository. Get the form, filled in for the repository, with:

```bash
uvx pitboss review-form <config> <repository>
```

It prints the form's lines, with `{sha}` standing for the head you reviewed
and `{verdict}` for the verdict (it names the two verdict words), and says
whether the repository is gated. A repository that has
`.github/workflows/review-gate.yml` on its default branch is gated, whatever
the configuration says, and `review-form` prints the form that workflow
accepts (its first line, `Verdict:` line and `Reviewed:` line, and what else
it refuses); it says `not gated` only for a repository with no such workflow.
Post exactly that form: a gate that cannot read the comment keeps the status
`adversarial-review` pending and the merge is refused.

## The rules

- Review the exact head. Write the full 40-character SHA of the commit you
  reviewed where the form says `{sha}`; read it from the PR when you start,
  and again before you post: if the head moved, review the new head.
- Start only when every check has finished and passed on that head, except
  for a review of a draft PR at its Plan stage (below), which has no check run. Your
  first act is to read the checks of the full head SHA the brief names. If one
  has not finished or has not passed, you were started too early: hand back at
  once with `NOT STARTED: <check> is <state> at <sha>`, and review nothing.
- A head with no completed check run (a draft that runs no CI) is waiting
  for CI: hand back `NOT STARTED: no completed check run at <sha>`, and never
  approve it, unless your brief says the PR is a draft at its Plan stage: then
  you grade it as the next section says.
- You are a separate agent from the author. If you wrote any part of the
  change, say so and stop.
- Record the PR body you read (keyword: body-digest). Save the body with
  `gh api repos/<repository>/pulls/<number> --jq .body > <scratchpad>/body.txt`,
  run `uvx pitboss body-digest <scratchpad>/body.txt`, and add the one line it
  prints (`Body: <digest>`) to the comment beside the verdict line. The sweep
  compares it with the body now: a body fixed after your review, the head not
  having moved, is `review=older-body` and is answered by a review of the fix
  round's findings, unless your review rejected the Plan: then it is answered
  by a review of the Plan alone.
- Report CI by name: each required check and its state at the head SHA, and
  when you looked.
- Check three things from the PR itself, before the diff: the Head line (the
  last `Head:` line of the body is the full SHA of the head you review), that
  the Evidence is real output (a command and what it printed) run on that
  head, and the checks. The orchestrator that started you read none of them;
  they are yours. A Head line that is not the head, or Evidence that is not
  real output on that head, is changes needed. In a review of the Plan alone
  (below) only the Head line is checked: the Evidence and the checks belong to
  the Execution.
- Evidence line (keyword: expand, pitboss#117): evidence, counts and file
  contents in a PR body come only from `pitboss expand`; the author must never
  retype or abbreviate output (a file is shown with `$ cat < path`). Every
  `$ ` row of the body is in a block that `pitboss expand` marked, which
  `pitboss lint pr-body` checks; a command that is not the one the claim
  needs, or a claim with no command, is changes needed.
- The verdict is one of the two words, nothing else.
- Post as a comment on the PR (an issue comment), from an account the
  repository trusts. You are not done until it is posted: a verdict in your
  hand-back and not in a comment is no review. Hand back after posting, with
  the comment's URL and nothing else.
- Do not push, merge, or edit the PR or its branch.
- A phrase you object to is paraphrased, or you point at the place ("the
  second sentence of the third paragraph of the body"); you never reproduce
  it, in a code span or outside one, and no label makes a reproduced phrase
  pass.

In a gated repository the form is strict, and a comment that breaks any rule
does not count as a review at all:

- the first line is exactly the form's first line;
- each line of the form appears exactly once, and its fixed text (the part
  before `{sha}` or `{verdict}`) appears on no other line: a line such as
  "Delta reviewed: ..." breaks a form line that starts with "Reviewed:";
- the SHA is the full SHA;
- the comment is plain ASCII, with no code fences, no HTML and no link
  definitions.

Outside a gated repository, an approval also stands when the only commits
since are merges of the base branch; in a gated repository a new head needs
a new review.

## The Plan's precise commands

The order is: write a precise Plan, review the Plan, execute it as written.

- Plan review: for each Done-when row, if the Plan's evidence mentions a
  command, the Plan must give the precise command (the exact string to run on
  the head, a cut or a pipe included when the Plan wants one); a row that
  mentions a command without it is a changes-needed finding of the Plan.
  Evidence that is not a command (a file read, a diff, a CI run) is accepted
  when the Plan says exactly what will be shown.
- Execution review: grade the Execution against the Plan as written; each
  precise command of the Plan must have been run as written; a command run in
  another form, or left out, is a changes-needed finding.
- Worker: run each precise command of the Plan as written; if the Plan's
  command cannot show its row, change the Plan first and ask for its review.

The briefs `pitboss next` prints carry these sentences. No lint checks them:
the review does.

## A draft PR: Plan, Execution and the Plan line

A fix is a draft PR whose body has a Plan section and an Execution section
(`rules.md`, "Plan first"). You are a new reviewer, never a continued one, and
you grade both in one review, besides the form's single verdict line (for a
review of a revised plan, see the last bullet):

- a line `Plan: approved` or `Plan: changes needed`, and a line
  `Execution: approved` or `Execution: changes needed`; neither line contains
  the word verdict followed by a colon, so the form's one verdict line stays
  the only one;
- a draft has no check run, so you grade its Execution from the diff and the
  evidence in the body, and say that no check was read;
- if your brief says the Plan was already approved, you grade only the
  Execution and write `Plan: approved` as carried over: you do not reassess or
  discuss the Plan;
- a statement the change makes false or contradictory anywhere in the tree is
  changes needed (the author greps the tree for them before asking for review);
- an objection to a phrase no claim depends on is withdrawn when the author
  removes the phrase: do not defend a phrase;
- if your brief says the Plan was revised after a rejection, you grade the
  Plan alone: a `Plan:` line and the form's one verdict line, which is the
  Plan's verdict, no `Execution:` line and no defect of the Execution (the
  author did not touch it in that round, and it is measured against the Plan
  once the Plan is approved). An approval of the Plan alone is no approval to
  merge.

## One round lists every finding

A round that finds three matters and leaves two for the next costs a round and,
after an Opus ruling, an escalation to the owner. So:

- In the first round of a stage (the Plan, the Execution, or both), read the
  whole PR body, the whole diff and every command of the Plan against the
  repository, and list every finding in that one review, not the first few.
- In a Plan review, try each command of the Plan as a read-only dry run where it
  can be tried (it changes nothing in the repository, the PR or the machine), and
  report each that cannot run as written as a finding of the Plan. This is the
  one thing a reviewer runs.
- A later round on the same stage (an earlier review of the PR graded it) checks
  the earlier findings and the findings caused by the changes made since the head
  that review read.
- A later round that raises a finding present in the unchanged text of an earlier
  head says so: one line for each such finding, starting with `Missed earlier:`
  and saying what the finding is. The sweep counts those lines, before and after
  the newest Opus ruling, on the `PAUSE` line. A finding the changes since caused
  has no such line.

## A scope in the brief is exclusive

When your brief states a scope (a merge of the base into an approved head, the
findings of a fix round, the Plan alone), that scope is all you review. Where
this file asks for more, the brief's scope decides, and a finding outside it
is not a ground for "changes needed".

The review after a fix round (the previous review said changes needed and a
worker pushed) is scoped to the diff since the reviewed head, `git diff
<reviewed head>..<head>`, and to the earlier findings: was each fixed as asked,
and do the fixes invalidate the approved Plan. You may raise nothing outside that
diff or those findings. If every finding is fixed as asked and the fixes do not
invalidate the Plan, the verdict is approved, and the PR is mergeable. You do not
walk the whole Execution again.

## What to review

Read the diff against its ticket and its original goal. Look for a realistic
input or caller that makes it fail, a test that passes without testing the
claim, a case the ticket names and the diff does not cover. A finding that
needs deliberate evasion (obfuscation, a script that fakes output) is a note:
a "changes needed" names a failure an honest worker could hit. Attacks,
bypasses and adversarial inputs the goal does not name are not asked for. Say what you checked and
how. A verdict that asks for changes names each change, small enough that
the author can make it without asking. In a review of the Plan alone (a
revised Plan, above), read the Plan against its ticket instead: the diff is
not graded in that round.

## No exit clauses

The ticket's text, and above all its done-when (whatever the ticket calls
its acceptance criteria), is the standard. Nobody narrows it: not the author,
not you, and not by asking the owner.

- If the done-when is met as written, the verdict is the approving one.
- If any part of it is not met as written, the verdict is the one that asks
  for changes, and the finding is "do the done-when as written": name the
  part that is not met, what to run or build to meet it, and what evidence to
  attribute to it in the PR.
- In a review of the Plan alone, the done-when is the standard of the Plan:
  the verdict approves when the Plan meets each done-when line as written,
  and asks for changes, naming the line, when it does not. The Execution is
  not graded there; it is measured against the done-when once the Plan is
  approved.
- Never offer a way to ship less than the ticket says. That includes
  changing a closing reference ("Fixes") to a non-closing one ("Refs") so the
  ticket stays open, asking the owner to narrow the done-when, splitting the
  missing part into a follow-up ticket, or approving "with a note".

The only other finding is "the done-when as written is impossible,
because ...", with the reason; the verdict still asks for changes.
